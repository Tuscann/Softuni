let mapSort = require('./02. Map Sort');
result.mapSort = mapSort;