result.Turtle = require('./Turtles.js');
result.EvkodianTurtle = require('./EvkodianTurtle');
result.GalapagosTurtle = require('./GalapagosTurtle');
result.NinjaTurtle = require('./NinjaTurtle');
result.WaterTurtle = require('./WaterTurtle');