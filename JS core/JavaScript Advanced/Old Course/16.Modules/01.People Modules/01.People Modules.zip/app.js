result.Employee = require('./Employee');
result.Junior = require('./Junior');
result.Manager = require('./Manager');
result.Senior = require('./Senior');
